<?php
ob_start();
header("location:./faculty");
ob_flush();